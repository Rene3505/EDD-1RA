
package eva1_7_arreglos_size;


public class EVA1_7_ARREGLOS_SIZE {


    public static void main(String[] args) {
        int[] original = new int[10];
        System.out.println(original);
        for (int i = 0; i < original.length; i++) { //LLENAR CON DATOS ALEATORIOS
            original[i] = (int)(Math.random()*100);
        }
        for (int i = 0; i < original.length; i++) { //IMPRIMIR
            System.out.println("["+ original[i]+"]");
        }
        System.out.println("");
        //CAMBIAR EL TAMAÑO(NO SE PUEDE)
        //RESPALDO
        int[] respaldo = new int[original.length];
        for (int i = 0; i < respaldo.length; i++) {
            respaldo[i] = original[i];
        }
        
        original = new int[5];
        
        for (int i = 0; i < original.length; i++) { //TRASPASAR DATOS DE RESPALDO AL ORIGINAL
            original[i] = respaldo[i];
        }
        
        System.out.println(original);
        for (int i = 0; i < original.length; i++) { //IMPRIMIR ARREGLO "MODIFICADO"
            System.out.println("["+ original[i]+"]");
        }
        
        System.out.println("");
        System.out.println("--RESPALDO--");
        for (int i = 0; i < 10; i++) {
            System.out.println("["+ respaldo[i]+"]");
        }
    }
    
}
