
package eva1_4_objetos;


public class EVA1_4_OBJETOS {


    public static void main(String[] args) {
        Prueba prueba = new Prueba();
        System.out.println(prueba);
        //ELIMINAR prueba:
        //Terminar el programa --> Garbage collector (libera memoria automáticamente)
        //eliminar "directamente" el objeto:
        prueba = null; //prueba se queda huérfana y sin dirección y el garbage collector elimina la memoria heap.
    }
}


    class Prueba{
    
    }
    

