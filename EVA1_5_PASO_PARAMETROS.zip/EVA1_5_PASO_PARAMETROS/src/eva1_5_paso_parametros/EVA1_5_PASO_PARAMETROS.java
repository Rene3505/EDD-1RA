
package eva1_5_paso_parametros;


public class EVA1_5_PASO_PARAMETROS {


    public static void main(String[] args) {
        int i = 5;
        System.out.println("Valor de i= "+i);
        incrementar(i);
        System.out.println("Valor de i (despues de incrementar) = "+i);
        //AHORA PASO POR REFERENCIA
        Prueba prueba = new Prueba();
        System.out.println("Valor de Prueba: "+ i);
        incrementarObj(prueba);
        System.out.println("Valor de prueba.y (despues de incrementar) = "+prueba.y);
    }
    
    public static void incrementar(int valor){
        valor++;
    }
    public static void incrementarObj(Prueba objeto){
        objeto.y++;
    }
    
}

class Prueba{
    int y = 5;
    
}
